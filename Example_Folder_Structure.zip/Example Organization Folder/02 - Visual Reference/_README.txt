[02 - Visual Reference]
무드보드, 레퍼런스 이미지·영상, 스타일 앵커, Style Kit 자료
