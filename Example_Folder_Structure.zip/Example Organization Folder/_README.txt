Artlist Academy · AI 프로젝트 예시 폴더 구조
(Tutorial「AI 영상 제작, 기획부터 작업 환경까지 준비하기」01:39~05:16)

00 - Admin               프로젝트 관리 문서
01 - Script              대본·샷리스트·스토리보드
02 - Visual Reference    무드보드·레퍼런스·스타일 앵커
03 - Characters & Props  캐릭터·의상·소품 시트
04 - Locations           로케이션 시트
05 - Production          생성 결과물
06 - Audio               음악·효과음·보이스오버
07 - Edit                편집 프로젝트
08 - Deliverables        최종 납품본
Prompt Log               프롬프트 기록 (prompt-log.csv)

폴더 이름 앞의 번호는 작업 순서이자 정렬 순서입니다. 프로젝트마다 이 폴더를 복사해 이름만 바꿔 쓰세요.
각 폴더의 _README.txt 는 확인 후 지워도 됩니다.
제공: 루비콘 (Artlist 한국 공식 리셀러)
