[08 - Deliverables]
최종 납품 파일 (버전·해상도·플랫폼별)
